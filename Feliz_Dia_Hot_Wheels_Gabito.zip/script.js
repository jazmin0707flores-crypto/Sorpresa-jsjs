const openGift = document.getElementById("openGift");
const card = document.getElementById("card");
const reveal = document.getElementById("reveal");
const again = document.getElementById("again");
const confetti = document.getElementById("confetti");

function celebrate(){
  confetti.innerHTML = "";
  const pieces = ["♥","✦","◆","★"];
  for(let i=0;i<70;i++){
    const p=document.createElement("span");
    p.className="piece";
    p.textContent=pieces[Math.floor(Math.random()*pieces.length)];
    p.style.left=Math.random()*100+"vw";
    p.style.fontSize=(10+Math.random()*15)+"px";
    p.style.animationDuration=(2.2+Math.random()*2.2)+"s";
    p.style.animationDelay=(Math.random()*.7)+"s";
    p.style.transform=`rotate(${Math.random()*180}deg)`;
    confetti.appendChild(p);
  }
}
function open(){
  card.style.display="none";
  reveal.classList.add("show");
  reveal.setAttribute("aria-hidden","false");
  celebrate();
  window.scrollTo({top:0,behavior:"smooth"});
}
function reset(){
  reveal.classList.remove("show");
  reveal.setAttribute("aria-hidden","true");
  card.style.display="";
  confetti.innerHTML="";
}
openGift.addEventListener("click",open);
again.addEventListener("click",reset);
